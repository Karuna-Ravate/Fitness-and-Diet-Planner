package com.acc.services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;
import java.util.Scanner;

import com.acc.model.Person;
import com.acc.services.Operable;


public class Management {
    public static void main(String[] args) {
        try {
            // Establishing database connection
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Management", "root", "karuna1864");
            Operable operable = new OperableImple(con);
            Scanner sc = new Scanner(System.in);

            while (true) {
                System.out.println("\nMenu:");
                System.out.println("1. Add User");
                System.out.println("2. Find All Users");
                System.out.println("3. Find User by ID");
                System.out.println("4. Update Steps");
                System.out.println("5. Set Step Goal");
                System.out.println("6. Add Meal");
                System.out.println("7. Get Calories Burned");
                System.out.println("8. Exit");
                System.out.print("Enter your choice: ");
                int choice = sc.nextInt();
                sc.nextLine(); // Consume newline

                switch (choice) {
                    case 1: // Add User
                        operable.adduser();
                        break;
                    case 2: // Find All Users
                        List<Person> users = operable.findAll();
                        if (users.isEmpty()) {
                            System.out.println("No users found.");
                        } else {
                            for (Person user : users) {
                                System.out.println(user);
                            }
                        }
                        break;
                    case 3: // Find User by ID
                        System.out.print("Enter User ID: ");
                        int id = sc.nextInt();
                        sc.nextLine(); // Consume newline
                        Person user = operable.find(id);
                        if (user != null) {
                            System.out.println(user);
                        } else {
                            System.out.println("User not found.");
                        }
                        break;
                    case 4: // Update Steps
                        operable.updatesteps();
                        break;
                    case 5: // Set Step Goal
                        operable.setstepgoal();
                        break;
                    case 6: // Add Meal
                        operable.addmeal();
                        break;
                    case 7: // Get Calories Burned
                        operable.getcaloriesburned();
                        break;
                    case 8: // Exit
                        System.out.println("Exiting...");
                        con.close(); // Close the database connection
                        sc.close();
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice. Please try again.");
                        break;
                }
            }
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
