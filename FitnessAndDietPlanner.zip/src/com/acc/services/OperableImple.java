package com.acc.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.acc.model.Person;

public class OperableImple implements Operable {
    private Connection con;
    private final Scanner sc = new Scanner(System.in);

    // Constructor to initialize the database connection
    public OperableImple(Connection con) {
        this.con = con;
    }

    @Override
    public void adduser() {
        try {
            System.out.println("Enter the username:");
            String userName = sc.nextLine();
            System.out.println("Enter the user age:");
            int age = sc.nextInt();
            System.out.println("Enter the height (in cm):");
            double height = sc.nextDouble();
            System.out.println("Enter the weight (in kg):");
            double weight = sc.nextDouble();
            sc.nextLine(); // Consume newline
            System.out.println("Enter the gender (M/F):");
            String gender = sc.nextLine();
            System.out.println("Enter daily steps goal:");
            int dailySteps = sc.nextInt();
            System.out.println("Enter daily calorie intake goal:");
            int dailyCalories = sc.nextInt();
            sc.nextLine(); // Consume newline

            String query = "INSERT INTO Person (userName, age, height, weight, gender, dailystepstodo, dailycaloriesintake) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setString(1, userName);
                ps.setInt(2, age);
                ps.setDouble(3, height);
                ps.setDouble(4, weight);
                ps.setString(5, gender);
                ps.setInt(6, dailySteps);
                ps.setInt(7, dailyCalories);
                ps.executeUpdate();
            }
            System.out.println("User added successfully!");
        } catch (SQLException e) {
            System.err.println("Error adding user: " + e.getMessage());
        }
    }

    @Override
    public List<Person> findAll() {
        List<Person> users = new ArrayList<>();
        try {
            String query = "SELECT * FROM Person";
            try (PreparedStatement ps = con.prepareStatement(query);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    Person user = new Person(
                            rs.getString("userName"),
                            rs.getInt("age"),
                            rs.getDouble("height"),
                            rs.getDouble("weight"),
                            rs.getString("gender"),
                            rs.getInt("dailystepstodo"),
                            rs.getInt("dailycaloriesintake")
                    );
                    users.add(user);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving users: " + e.getMessage());
        }
        return users;
    }

    @Override
    public Person find(int id) {
        Person user = null;
        try {
            String query = "SELECT * FROM Person WHERE id = ?";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setInt(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        user = new Person(
                                rs.getString("userName"),
                                rs.getInt("age"),
                                rs.getDouble("height"),
                                rs.getDouble("weight"),
                                rs.getString("gender"),
                                rs.getInt("dailystepstodo"),
                                rs.getInt("dailycaloriesintake")
                        );
                    } else {
                        System.out.println("User not found.");
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error finding user: " + e.getMessage());
        }
        return user;
    }

    @Override
    public void updatesteps() {
        try {
            System.out.println("Enter user ID:");
            int id = sc.nextInt();
            System.out.println("Enter the updated step count:");
            int steps = sc.nextInt();

            String query = "UPDATE Person SET dailystepstodo = ? WHERE id = ?";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setInt(1, steps);
                ps.setInt(2, id);
                int rowsUpdated = ps.executeUpdate();
                if (rowsUpdated > 0) {
                    System.out.println("Step count updated successfully!");
                } else {
                    System.out.println("User not found.");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error updating steps: " + e.getMessage());
        }
    }

    @Override
    public void setstepgoal() {
        try {
            System.out.println("Enter user ID:");
            int id = sc.nextInt();
            System.out.println("Enter the new daily step goal:");
            int stepGoal = sc.nextInt();

            String query = "UPDATE Person SET dailystepstodo = ? WHERE id = ?";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setInt(1, stepGoal);
                ps.setInt(2, id);
                int rowsUpdated = ps.executeUpdate();
                if (rowsUpdated > 0) {
                    System.out.println("Step goal updated successfully!");
                } else {
                    System.out.println("User not found.");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error setting step goal: " + e.getMessage());
        }
    }

    @Override
    public void addmeal() {
        try {
            System.out.println("Enter user ID:");
            int id = sc.nextInt();
            sc.nextLine(); // Consume newline
            System.out.println("Enter meal description:");
            String meal = sc.nextLine();
            System.out.println("Enter calories for this meal:");
            int calories = sc.nextInt();

            String query = "INSERT INTO Meals (userId, meal, calories) VALUES (?, ?, ?)";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setInt(1, id);
                ps.setString(2, meal);
                ps.setInt(3, calories);
                ps.executeUpdate();
            }
            System.out.println("Meal added successfully!");
        } catch (SQLException e) {
            System.err.println("Error adding meal: " + e.getMessage());
        }
    }

    @Override
    public void getcaloriesburned() {
        try {
            System.out.println("Enter user ID:");
            int id = sc.nextInt();

            String query = "SELECT SUM(calories) AS totalCalories FROM Exercises WHERE userId = ?";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setInt(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        int totalCalories = rs.getInt("totalCalories");
                        System.out.println("Total calories burned: " + totalCalories);
                    } else {
                        System.out.println("No data found for this user.");
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error calculating calories burned: " + e.getMessage());
        }
    }
}
