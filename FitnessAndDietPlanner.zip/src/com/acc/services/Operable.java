package com.acc.services;

import java.util.List;

import com.acc.model.Person;


public interface Operable {
	void adduser();
	List<Person> findAll();
	Person find(int id);
	void updatesteps();
	void setstepgoal();
	void addmeal();
	void getcaloriesburned();
	

}
