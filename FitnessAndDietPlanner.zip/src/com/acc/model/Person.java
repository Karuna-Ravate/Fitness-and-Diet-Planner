package com.acc.model;

public class Person {
	private String userName;
	private int age;
	private double height;
	private double weight;
	private String gender;
	private int dailystepstodo;
	private int dailycaloriesintake;
	public Person(String userName, int age, double height, double weight, String gender, int dailystepstodo,
			int dailycaloriesintake) {
		super();
		this.userName = userName;
		this.age = age;
		this.height = height;
		this.weight = weight;
		this.gender = gender;
		this.dailystepstodo = dailystepstodo;
		this.dailycaloriesintake = dailycaloriesintake;
	}
	public String getUserName() {
		return userName;
	}
	public  void setUserName(String userName) {
		this.userName = userName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getDailystepstodo() {
		return dailystepstodo;
	}
	public void setDailystepstodo(int dailystepstodo) {
		this.dailystepstodo = dailystepstodo;
	}
	public int getDailycaloriesintake() {
		return dailycaloriesintake;
	}
	public void setDailycaloriesintake(int dailycaloriesintake) {
		this.dailycaloriesintake = dailycaloriesintake;
	}
	@Override
	public String toString() {
		return "Person [userName=" + userName + ", age=" + age + ", height=" + height + ", weight=" + weight
				+ ", gender=" + gender + ", dailystepstodo=" + dailystepstodo + ", dailycaloriesintake="
				+ dailycaloriesintake + "]";
	}
	
}
